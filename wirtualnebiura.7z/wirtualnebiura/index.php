<?php
session_start();
require_once('vendor/autoload.php');
require_once('constans.php');
spl_autoload_register('classLoader');

$site = new Site();

$action = 'showMain';
if (isset($_GET['action'])) {
  $action = $_GET['action'];
} elseif( isset($_POST['action'])) {
  $action = $_POST['action'];
}

switch($action){
  case 'sendEmail';
    switch($site->sendEmail()){
      case SENDING_OK:
        $site->setMessage("Email został wysłany.");
        break;
      case SERVER_ERROR:
      default :
        $site->setMessage("Błąd serwera, wiadomość nie została wysłana.");
    }
    header('Location:');
    include 'templates/mainTemplate.php';
    break;
  case 'acceptCookies';
      setcookie("acceptCookies", true, time() + (10 * 365 * 24 * 60 * 60) );
    break;
  default:
    include 'templates/mainTemplate.php';
}

function classLoader($nazwa){
  if(file_exists("class/$nazwa.php")){
    require_once("class/$nazwa.php");
  } else {
    throw new Exception("Brak pliku z definicją klasy.");
  }
}
