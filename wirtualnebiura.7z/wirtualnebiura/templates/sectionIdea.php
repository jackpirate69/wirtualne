<?php   if(!isset($site)) die(); ?>
<div  id="idea"  class="row">
  <div class="container">
    <div class="col-md-12">
      <h2 class="text-center">Idea</h2>
      <p class="lead">Używasz adresu realnie funkcjonującego biurowca jako siedziby własnej firmy oraz adresu korespondencyjnego. Otrzymujesz kompleksową obsługę poczty przychodzącej, Twoje listy przechowamy do momentu odbioru, wyślemy mailem (jeżeli takie będzie Twoje życzenie) lub odeślemy na wskazany adres. Uzyskujesz obniżenie kosztów działalności przy jednoczesnej rejestracji firmy poza adresem zamieszkania.</p>
    </div>
  </div>
</div>
