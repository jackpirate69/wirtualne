<?php   if(!isset($site)) die(); ?>
<div id="start" class="row">
  <div class="jumbotron ">
    <h1>WIRTUALNE BIURO</h1>
    <p>DLA TWOJEGO BIZNESU</p>
  </div>
</div>
