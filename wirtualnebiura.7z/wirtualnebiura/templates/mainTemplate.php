<?php   if(!isset($site)) die(); ?>
<?php
if(isset($_POST['confirm'])) {
  unset($_SESSION['message_sent']);
}


?>
<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Wirtualne Biura - Adres do rejestracji firmy</title>

	<meta name="description" content="Używasz adresu realnie funkcjonującego biurowca jako siedziby własnej firmy oraz adresu korespondencyjnego. Otrzymujesz kompleksową obsługę poczty przychodzącej. Uzyskujesz obniżenie kosztów działalności przy jednoczesnej rejestracji firmy poza adresem zamieszkania." />
	<meta name="keywords" content="wirtualne biura, biuro, opole, wynajem biura, biuro na godziny, siedziba firmy, siedziba, wirtualna siedziba " />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="public/bootstrap/bootstrap.css" type="text/css" />
	<link rel="stylesheet" href="public/css/style.css" type="text/css" />
	<link rel="stylesheet" href="public/css/fontello.css" type="text/css" />
	<link href="https://fonts.googleapis.com/css?family=Mukta+Malar:300,400,700&amp;subset=latin-ext" rel="stylesheet">
  <script src="public/jquery-3.3.1.min.js"></script>
  <script src="public/jquery.waypoints.min.js"></script>
  <script src="public/jquery.scrollTo.min.js"></script>
  <script src="public/bootstrap/bootstrap.min.js"></script>
  <script src='https://www.google.com/recaptcha/api.js'></script>
  <script src="public/js/faq.js"></script>
  <script src="public/js/menu.js"></script>
</head>
<body>
	<div class="container-fluid">
  	<header>
      <?php include "templates/mainMenu.php"?>
      <div id="offset" class="row">
      </div>
      <?php include "templates/topBaner.php"?>
  	</header>
  	<main>
      <?php include "templates/sectionIdea.php"?>
      <?php include "templates/sectionOffer.php"?>
      <?php include "templates/sectionPrice.php"?>
      <?php include "templates/sectionAdditives.php"?>
      <?php include "templates/sectionFAQ.php"?>
      <?php include "templates/sectionContact.php"?>
      <?php include "templates/footer.php"?>
      <?php
      if(!isset($_COOKIE['acceptCookies'])){
        include "templates/cookies-info.php";
      }
      ?>
    </main>
  </div>
</body>
</html>
<?php
if(isset($_SESSION['message_not_sent']) || isset($_SESSION['message_sent']) || isset($_POST['confirm'])) {
  echo "<script>
        $.scrollTo($('#contact2'), 500);
        console.log('i am');
        </script>";
  unset($_SESSION['message_not_sent']);
}
 ?>
