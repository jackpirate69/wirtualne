<?php   if(!isset($site)) die(); ?>

<div id="price" class="row">
  <div class="container">
    <h2 class="text-center">Cena</h2>
    <div class="col-md-4">
      <div class="price-column annual-price">
        <span class="text-center">roczny abonament</span>
        <p class="text-center"><b>49 zł *</b><br>miesięcznie</p>
      </div>
    </div>
    <div class="col-md-4">
      <div class="price-column half-yearly-price">
        <span class="text-center">półroczny abonament </span>
        <p class="text-center"><b>54 zł *</b><br>miesięcznie</p>
      </div>
    </div>
    <div class="col-md-4 ">
      <div class="price-column monthly-price">
        <span class="text-center">kwartalny abonament</span>
        <p class="text-center"><b>59 zł *</b><br>miesięcznie</p>
      </div>
    </div>
    <p>* cena netto </p>
  </div>
</div>
