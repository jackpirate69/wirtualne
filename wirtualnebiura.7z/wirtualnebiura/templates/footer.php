<?php   if(!isset($site)) die(); ?>
<div  id="footer"  class="row">
  <div class="container">
    <p>&copy; <?php echo date("Y"); ?> wirtualnebiura.com.pl</p>
  </div>
</div>
