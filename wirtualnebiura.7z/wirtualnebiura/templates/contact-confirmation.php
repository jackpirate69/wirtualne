<?php   if(!isset($site)) die(); ?>
<form method="post" action = "index.php?action=newEmail">
  <div class="row">
    <div class="col-md-12 text-center">
      <p>Wiadomość została wysłana.</p>
      <p>Skontaktujemy się z Państwem tak szybko jak to tylko będzie możliwe.</p>
      <br>
      <input style="visibility: hidden" type="text" name="confirm" value="confirm">
      <input class="form-control btn btn-primary"  type="submit" value="Wyślij kolejną wiadomość">
    </div>
  </div>
</form>
