<?php   if(!isset($site)) die(); ?>
<div  id="additives"  class="row">
  <div class="container">
    <h2 class="text-center">Dodatki</h2>
    <p>Dostosowujemy warunki współpracy do indywidualnych potrzeb klienta dlatego przedstawimy Twojej firmie ofertę z uwzględnieniem sprecyzowanych wymagań. Zajmujemy się również wynajmem tradycyjnych powierzchni biurowych oraz handlowych.</p>
  </div>
</div>
