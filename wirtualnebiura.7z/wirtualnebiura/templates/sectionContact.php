<?php   if(!isset($site)) die(); ?>
<div  id="contact"  class="row">
    <iframe src="https://www.google.com/maps/embed/v1/place?q=(Biurowiec%20Familia)&key=AIzaSyBaIq44X1XHmqwZtFWOn62vsWqD_F9Xi5I" width="100%" height="600px" style="border:none;"></iframe>
</div>
<div  id="contact2"  class="row">
  <div class="container">
    <h2 class="text-center">Kontakt</h2>
    <div class="col-md-6 text-center">
      <h4><i class="icon-location"></i>Siedziba</h4>
      <p>
        Biurowiec Familia<br />
        ul. 1-go Maja 30a<br />
        45-355 Opole<br />
      </p>
      <h4><i class="icon-phone"></i>Zadzwoń</h4>
      <p>
        Marek Tarasiuk<br />
        <a href="tel:+48 693 582 295">tel. 693 582 295 </a>
      </p>
    </div>
    <div class="col-md-6 contact-form">
      <h4 class="text-center">Formularz kontaktowy</h4>
    <?php
      if(!isset($_SESSION['message_sent'])) include 'contact-form.php';
      else include 'contact-confirmation.php';
    ?>

    </div>
  </div>
</div>
