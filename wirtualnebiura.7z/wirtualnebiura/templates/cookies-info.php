<div class="cookies-info">
  <div class="col-md-8">
    <p>
      Strona wykorzystuje pliki cookies w celach analitycznych.
      <a href="resource/doc/polityka_prywatnosci.pdf" target="_blank">Polityka prywatności</a>
    </p>
  </div>
  <div class="col-md-4 text-center">
    <button id ="cookies-accept" class="btn btn-success btn-xs">Zgadzam się</button>
  </div>
</div>
<script>
$( document ).ready(function() {
  $("#cookies-accept").click(function(){
    $.ajax({
      type: "POST",
      url: "index.php",
      data: {
        action: "acceptCookies"
      },
      dataType: "json"
    });
    $(".cookies-info").hide(300);
    console.log("klik");
  });
});
</script>
