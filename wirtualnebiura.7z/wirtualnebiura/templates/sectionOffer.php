<?php   if(!isset($site)) die(); ?>
<div id="offer" class="row">
  <div class="container">
    <h2 class="text-center">Oferta</h2>
    <div class="col-md-6">
      <h3>Pełny pakiet usług obejmuje:</h3>
      <ul class="list-unstyled">
        <li>udostępnienie adresu do rejestracji firmy,</li>
        <li>udostępnienie adresu do korespondencji,</li>
        <li>odbiór korespondencji (w tym przesyłki rejestrowane),</li>
        <li>informowanie o odebranej korespondencji,</li>
        <li>skanowanie odebranej korespondencji,</li>
        <li>przechowywanie odebranej korespondencji.</li>
        <li>odsyłanie na wskazany adres (lub paczkomat)</li>
      </ul>
    </div>
    <div class="col-md-6">
      <img src="resource/img/handshake.jpg" />
    </div>
  </div>
</div>
