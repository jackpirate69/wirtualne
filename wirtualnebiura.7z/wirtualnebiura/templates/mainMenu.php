<?php   if(!isset($site)) die(); ?>
<nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a href="#"><img src="resource/img/logo.png"></a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li class="active"><a data-link="start">Start</a></li>
            <li><a data-link="idea">Idea</a></li>
            <li><a data-link="offer">Oferta</a></li>
            <li><a data-link="price">Cennik</a></li>
            <li><a data-link="additives">Dodatki</a></li>
            <li><a data-link="faq">FAQ</a></li>
            <li><a data-link="contact">Kontakt</a></li>
          </ul>
        </div><!--/.nav-collapse --->
      </div>
  </nav>
