<?php   if(!isset($site)) die(); ?>
<div  id="faq"  class="row">
  <div class="container">
    <div class="col-md-12">
      <h2 class="text-center">Pytania i odpowiedzi</h2>
      <div class="faq-segment">
          <div class="question">
            <p>Co to jest Wirtualne Biuro?
            <span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span>
            </p>
          </div>
          <div class="answer">
            Wirtualne Biuro, inaczej e-biuro to usługa polegająca na całkowitym outsourcingu obsługi biurowej bez konieczności fizycznej obecności przedsiębiorcy w danym miejscu.
Umożliwia użytkownikom znaczną redukcję kosztów związanych z wynajmem lokalu i zatrudnieniem pracowników biurowych. Wirtualne biura zapewniają rejestrację przedsiębiorstwa pod swoim adresem, dzięki czemu osoby prowadzące działalność w domu lub też mobilni specjaliści mogą korzystać z prowadzenia przedsiębiorstwa pod adresem jednego z centrów biznesowych.
          </div>
      </div>
      <div class="faq-segment">
        <div class="question">
          <p>Historia wirtualnych biur
          <span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span>
          </p>
        </div>
        <div class="answer">
          Pomysł stworzenia wirtualnego biura pojawił się już w 1994 r. Osobą, która chciała ułatwić funkcjonowanie podmiotów gospodarczych i wpadła na pomysł stworzenia takiego miejsca był Ralph Gregory. Przeprowadził on obserwacje, z których wynikało, że szerokie grono przedsiębiorców nie potrzebuje prowadzenia własnego biura i chce zaoszczędzić koszty. Idea wirtualnego biura zyskała na wartości i już w 1995 roku pojawili się pierwsi klienci. Firma założona przez Ralpha Gregory funkcjonuje do dziś i cieszy się ogromnym zainteresowaniem klientów.
        </div>
      </div>
      <div class="faq-segment">
          <div class="question">
            <p>Jakie będę miał korzyści z Wirtualnego biura w stosunku do tradycyjnego biura?
            <span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span>
            </p>
          </div>
          <div class="answer">
            Przedsiębiorca, który postanowi korzystać z wirtualnego biura może liczyć na wiele korzyści, które wiążą się z tą opcją:
            <ul>
            <li>znaczny spadek kosztów utrzymania biura,</li>
            <li>spadek kosztów związanych z wypłacaniem wynagrodzeń pracownikom,</li>
            <li>uproszczenie w wypromowaniu firmy,</li>
            <li>elastyczność w kwestii lokalizacji,</li>
            <li>doświadczenie i bezpieczeństwo,</li>
            <li>profesjonalny personel,</li>
            <li>anonimowość prywatnych danych,</li>
            <li>szereg dodatkowych usług administracyjnych.</li>
          </ul>
        </div>
      </div>
      <div class="faq-segment">
          <div class="question">
            <p>Czy pomożecie mi w założeniu firmy?
            <span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span>
            </p>
          </div>
          <div class="answer">
            Tak, na życzenie klienta zajmiemy się procesem rejestracji indywidualnej działalności gospodarczej lub sp. z o.o., jak również zajmiemy się prowadzeniem księgowości.
        </div>
      </div>
      <div class="faq-segment">
          <div class="question">
            <p>Czy adres pod jakim prowadzone jest Wirtualne Biuro faktycznie istnieje?
            <span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span>
            </p>
          </div>
          <div class="answer">
            <p>Tak, pod adresem Opole, ul. 1-go Maja 30a znajduje się Biurowiec FAMILIA, który świadczy również najem lokali biurowych, handlowych oraz usługowych.</p>
        </div>
      </div>
      <div class="faq-segment">
          <div class="question">
            <p>Pod jakie urzędy będę podlegał/a korzystając z Wirtualnego biura?
            <span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span>
            </p>
          </div>
          <div class="answer">
            W zależności od rodzaju prowadzonej działalności możesz korzystać ze wszystkich, bądź niektórych urzędów:
            <ul>
              <li>Pierwszy Urząd Skarbowy w Opolu</li>
              <li>ZUS oddział w Opolu</li>
              <li>Opolski Urząd Wojewódzki</li>
              <li>Urząd Miasta Opola</li>
              <li>Powiatowy Urząd Pracy w Opolu</li>
            </ul>
          </div>
      </div>
      <div class="faq-segment">
          <div class="question">
            <p>Przykładowe odległości od naszego biura:
            <span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span>
            </p>
          </div>
          <div class="answer">
            Poniżej podajemy odległości dzielące Twoje Wirtualne Biuro od przykładowych miejsc w Opolu.
            <ul>
            <li>Pierwszy Urząd Skarbowy w Opolu - 0,9 km</li>
            <li>ZUS oddział w Opolu - 2,9 km</li>
            <li>Opolski Urząd Wojewódzki - 1,9 km</li>
            <li>Powiatowy Urząd Pracy w Opolu - 2,8 km</li>
            <li>Urząd Miasta Opola - 1,8 km</li>
            <li>Dworzec Główny PKS - 0,85 km</li>
            <li>Dworzec Główny PKP - 1,1 km</li>
            <li>Urząd Pocztowy - 1,1 km</li>
          </ul>
        </div>
      </div>
  </div>
</div>
</div>
