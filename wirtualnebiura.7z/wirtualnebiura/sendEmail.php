<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer(true);                              // Passing `true` enables exceptions
try {
    //Server settings
    //$mail->SMTPDebug = 2;                                 // Enable verbose debug output
    $mail->CharSet = 'UTF-8';
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'noreplywirtualnebiura@gmail.com';                 // SMTP username
    $mail->Password = 'ZAQ!2wsx';                           // SMTP password
    $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 587;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('noreplywirtualnebiura@gmail.com', 'Wirtualnebiura.com');
    $mail->addAddress('marek.tarasiuk@icloud.com', 'Marek Tarasiuk');     // Add a recipient
    $mail->addBcc('p.nieslony@gmail.com', 'webmaster');
    $mail->addReplyTo('marek.tarasiuk@icloud.com', 'Marek Tarasiuk');

    //Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Wiadomość ze strony WirtualneBiura.com.pl';
    $mail->Body  = $messageToSend1;
    $mail->send();
} catch (Exception $e) {
    echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
}
