<?php
session_start();
if(isset($_POST['pass'])){
	if($_POST['pass'] == "WB2018") {
		$_SESSION['pass'] = "ok";
		header("Location: ../ ");
	} else {
		$_SESSION["error"] = '<p style="color:red">Błędne hasło</p>';
	}
}
 ?>
<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title></title>

	<meta name="description" content="Strona w budowie" />
	<meta name="keywords" content="strona w budowie" />
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="stylesheet" href="style.css" type="text/css" />

</head>

<body>
	<h1>Strona w budowie</h1>
	<div id="container">
		<form method="post">
			<input name="pass" type="password" placeholder="haslo" onfocus="this.placeholder=''" onblur="this.placeholder='haslo'"/>
			<?php if(isset($_SESSION["error"])) echo $_SESSION["error"];
			unset($_SESSION["error"]);
			?>
			<input type="submit" value="Zaloguj się" />
		</form>

	</div>

	<script>document.write('<script src="http://' + (location.host || 'localhost').split(':')[0] + ':35729/livereload.js?snipver=1"></' + 'script>')</script>
</body>
</html>
