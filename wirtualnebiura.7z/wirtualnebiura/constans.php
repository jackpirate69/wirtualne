<?php
  define("SENDING_OK", 1);
  define("SERVER_ERROR", 3);
