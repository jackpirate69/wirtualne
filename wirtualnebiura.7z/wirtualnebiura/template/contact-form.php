<form method="post">
  <div class="form-group">
    <label>Imię i nazwisko*</label>
    <input type="text" class="form-control" name="name" value="<?php
      if(isset($_SESSION['fr_name'])) {
          echo $_SESSION['fr_name'];
          unset($_SESSION['fr_name']);
      }
      ?>" required>
    <?php
        if(isset($_SESSION['e_name'])){
            echo '<div class="error">'.$_SESSION['e_name'].'</div>';
            unset($_SESSION['e_name']);
        }
    ?>
  </div>
  <div class="row">
    <div class="col-md-6">
      <div class="form-group">
        <label>E-mail</label>
        <input type="email" class="form-control" name="email" value="<?php
        if(isset($_SESSION['fr_email'])) {
            echo $_SESSION['fr_email'];
            unset($_SESSION['fr_email']);
        }
        ?>">
        <?php
            if(isset($_SESSION['e_email'])){
                echo '<div class="error">'.$_SESSION['e_email'].'</div>';
                unset($_SESSION['e_email']);
            }
        ?>
      </div>
    </div>
    <div class="col-md-6">
      <div class="form-group">
        <label>Telefon</label>
        <input type="tel" class="form-control" name="phone" value="<?php
        if(isset($_SESSION['fr_phone'])){
            echo $_SESSION['fr_phone'];
            unset($_SESSION['fr_phone']);
        }
        ?>">
        <?php
            if(isset($_SESSION['e_phone'])){
                echo '<div class="error">'.$_SESSION['e_phone'].'</div>';
                unset($_SESSION['e_phone']);
            }
        ?>
      </div>
    </div>
  </div>
  <div class="form-group">
    <label>Wiadomość*</label>
    <textarea  type="text" class="form-control" name="message"  rows="4" cols="10" required><?php
      if(isset($_SESSION['fr_message'])) {
          echo $_SESSION['fr_message'];
          unset($_SESSION['fr_message']);
      }
      ?></textarea>
    <?php
        if(isset($_SESSION['e_message'])){
            echo '<div class="error">'.$_SESSION['e_message'].'</div>';
            unset($_SESSION['e_message']);
        }
    ?>
  </div>
  <div class="row">
    <div class="col-md-9">
      <div class="g-recaptcha" data-sitekey="6LcBcoUUAAAAADNq-mQL8bwMafli26MlRDqamI3N"></div>
      <?php
      if(isset($_SESSION['e_bot'])){
          echo '<div class="error">'.$_SESSION['e_bot'].'</div>';
          unset($_SESSION['e_bot']);
      }
      ?>
    </div>
    <div class="col-md-3 text-right">
      <input class="form-control btn btn-primary" type="submit" value="Wyślij">
    </div>
  </div>
</form>
