<?php
session_destroy();
if(isset($_POST['confirm'])) {
  unset($_SESSION['message_sent']);
}

 if(isset($_POST['name'])){
		 //Udana walidacja? Załóżmy, że tak!
		 $wszystko_OK = true;

		 //Sprawdż poprawnośc nickname'a
		 $name = $_POST['name'];
		 //Sprawdzenie długości nicka
		 if(!isset($_POST['name'])){
				 $wszystko_OK = false;
				 $_SESSION['e_name'] = "To pole jest obowiązkowe";
		 }

		 // Sprawdz poprawnosc wartosci email
		 $email = $_POST['email'];

		 $emailB = filter_var($email, FILTER_SANITIZE_EMAIL);

		 if((filter_var($emailB, FILTER_VALIDATE_EMAIL)) == false || ($emailB != $email)){
				 $wszystko_OK = false;
				 $_SESSION['e_email'] = "Podaj poprawny adres email.";
		 }

		 // Sprawdz poprawnosc wartosci email
		 $phone = $_POST['phone'];

		 //Bot or not
		 $sekret = "6LcBcoUUAAAAACaUeAzLxqsOOK5HBE_AEGIpnU6M";
		 $sprawdz = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".$sekret."&response=".$_POST['g-recaptcha-response']);

		 $odpowiedz = json_decode($sprawdz);

		 if($odpowiedz->success == false){
				 $wszystko_OK = false;
				 $_SESSION['e_bot'] = "Potwierdź że nie jestes botem.";
		 }

		 //Sprawdż poprawnośc wiadomości
		 $message = $_POST['message'];
		 if((strlen($message)<10)){
				 $wszystko_OK = false;
				 $_SESSION['e_message'] = "Ta wiadomość jest zbyt krótka";
		 }

		 if($wszystko_OK){

			 $messageToSend1 = $name. " wysłał wiadomość za pomocą formularza na stronie o treści:<br><br>";
			 $messageToSend1.= $message;
			 if($phone)  $messageToSend1.= "<br><br>".$name." podał nr telefonu: ".$phone;
			 else  $messageToSend1.="<br><br>".$name." nie podał nr telefonu.";
       require('sendEmail.php');
       $_SESSION['message_sent'] = true;
		 } else {
			 // Zapamiętaj wprowadzone dane
			 $_SESSION['fr_name'] = $name;
			 $_SESSION['fr_email'] = $email;
			 $_SESSION['fr_phone'] = $phone;
			 $_SESSION['fr_message'] = $message;
       $_SESSION['message_not_sent'] = true;
		 }
	 }
?>
<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Wirtualne Biura - Adres do rejestracji firmy</title>

	<meta name="description" content="Używasz adresu realnie funkcjonującego biurowca jako siedziby własnej firmy oraz adresu korespondencyjnego. Otrzymujesz kompleksową obsługę poczty przychodzącej. Uzyskujesz obniżenie kosztów działalności przy jednoczesnej rejestracji firmy poza adresem zamieszkania." />
	<meta name="keywords" content="wirtualne biura, biuro, opole, wynajem biura, biuro na godziny, siedziba firmy, siedziba, wirtualna siedziba " />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="public/bootstrap/bootstrap.css" type="text/css" />
	<link rel="stylesheet" href="public/css/style.css" type="text/css" />
	<link rel="stylesheet" href="public/css/fontello.css" type="text/css" />

	<link href="https://fonts.googleapis.com/css?family=Mukta+Malar:300,400,700&amp;subset=latin-ext" rel="stylesheet">
	<script src="public/jquery-3.3.1.min.js"></script>
	<script src="public/jquery.waypoints.min.js"></script>
	<script src="public/jquery.scrollTo.min.js"></script>
	<script src="public/bootstrap/bootstrap.min.js"></script>
  <script src='https://www.google.com/recaptcha/api.js'></script>
	<script src="public/js/faq.js"></script>
	<script src="public/js/menu.js"></script>
</head>
<body>
	<div class="container-fluid">
	<header>
		<nav class="navbar navbar-default navbar-fixed-top">
		      <div class="container">
		        <div class="navbar-header">
		          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
		            <span class="sr-only">Toggle navigation</span>
		            <span class="icon-bar"></span>
		            <span class="icon-bar"></span>
		            <span class="icon-bar"></span>
		          </button>
		          <a href="#"><img src="resource/img/logo.png"></a>
		        </div>
		        <div id="navbar" class="navbar-collapse collapse">
		          <ul class="nav navbar-nav navbar-right">
		            <li class="active"><a data-link="start">Start</a></li>
		            <li><a data-link="idea">Idea</a></li>
		            <li><a data-link="offer">Oferta</a></li>
		            <li><a data-link="price">Cennik</a></li>
		            <li><a data-link="additives">Dodatki</a></li>
		            <li><a data-link="faq">FAQ</a></li>
		            <li><a data-link="contact">Kontakt</a></li>
		          </ul>
		        </div><!--/.nav-collapse --->
		      </div>
		    </nav>
	</header>

	<main>
		<div id="offset" class="row">
		</div>
		<div id="start" class="row">
			<div class="jumbotron ">
				<h1>WIRTUALNE BIURO</h1>
				<p>DLA TWOJEGO BIZNESU</p>
			</div>
		</div>
		<div  id="idea"  class="row">
			<div class="container">
				<div class="col-md-12">
					<h2 class="text-center">Idea</h2>
					<p class="lead">Używasz adresu realnie funkcjonującego biurowca jako siedziby własnej firmy oraz adresu korespondencyjnego. Otrzymujesz kompleksową obsługę poczty przychodzącej, Twoje listy przechowamy do momentu odbioru, wyślemy mailem (jeżeli takie będzie Twoje życzenie) lub odeślemy na wskazany adres. Uzyskujesz obniżenie kosztów działalności przy jednoczesnej rejestracji firmy poza adresem zamieszkania.</p>
				</div>
			</div>
		</div>
		<div id="offer" class="row">
			<div class="container">
				<h2 class="text-center">Oferta</h2>
				<div class="col-md-6">
					<h3>Pełny pakiet usług obejmuje:</h3>
					<ul class="list-unstyled">
						<li>udostępnienie adresu do rejestracji firmy,</li>
						<li>udostępnienie adresu do korespondencji,</li>
						<li>odbiór korespondencji (w tym przesyłki rejestrowane),</li>
						<li>informowanie o odebranej korespondencji,</li>
			      <li>skanowanie odebranej korespondencji,</li>
			      <li>przechowywanie odebranej korespondencji.</li>
			      <li>odsyłanie na wskazany adres (lub paczkomat)</li>
					</ul>
				</div>
				<div class="col-md-6">
					<img src="resource/img/handshake.jpg" />
				</div>
			</div>
		</div>
		<div id="price" class="row">
			<div class="container">
				<h2 class="text-center">Cena</h2>
				<div class="col-md-4">
					<div class="price-column annual-price">
						<span class="text-center">roczny abonament</span>
						<p class="text-center"><b>49 zł *</b><br>miesięcznie</p>
					</div>
				</div>
				<div class="col-md-4">
					<div class="price-column half-yearly-price">
						<span class="text-center">półroczny abonament </span>
						<p class="text-center"><b>54 zł *</b><br>miesięcznie</p>
					</div>
				</div>
				<div class="col-md-4 ">
					<div class="price-column monthly-price">
						<span class="text-center">kwartarly abonament</span>
						<p class="text-center"><b>59 zł *</b><br>miesięcznie</p>
					</div>
				</div>
				<p>* cena netto </p>
			</div>
		</div>
		<div  id="additives"  class="row">
			<div class="container">
				<h2 class="text-center">Dodatki</h2>
				<p>Dostosowujemy warunki współpracy do indywidualnych potrzeb klienta dlatego przedstawimy Twojej firmie ofertę z uwzględnieniem sprecyzowanych wymagań. Zajmujemy się również wynajmem tradycyjnych powierzchni biurowych oraz handlowych.</p>
			</div>
		</div>
		<div  id="faq"  class="row">
			<div class="container">
				<div class="col-md-12">
					<h2 class="text-center">Pytania i odpowiedzi</h2>
					<div class="faq-segment">
							<div class="question">
								<p>Co to jest wirtualne biuro?
								<span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span>
								</p>
							</div>
							<div class="answer">
								Wirtualne biuro, inaczej e-biuro to usługa polegająca na całkowitym outsourcingu obsługi biurowej bez konieczności fizycznej obecności przedsiębiorcy w danym miejscu.
		Umożliwia użytkownikom znaczną redukcję kosztów związanych z wynajmem lokalu i zatrudnieniem pracowników biurowych. Wirtualne biura zapewniają rejestrację przedsiębiorstwa pod swoim adresem, dzięki czemu osoby prowadzące działalność w domu lub też mobilni specjaliści mogą korzystać z prowadzenia przedsiębiorstwa pod adresem jednego z centrów biznesowych.
							</div>
					</div>
					<div class="faq-segment">
						<div class="question">
							<p>Historia wirtualnych biur
							<span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span>
							</p>
						</div>
						<div class="answer">
							Pomysł stworzenia wirtualnego biura pojawił się już w 1994 r. Osobą, która chciała ułatwić funkcjonowanie podmiotów gospodarczych i wpadła na pomysł stworzenia takiego miejsca był Ralph Gregory. Przeprowadził on obserwacje, z których wynikało, że szerokie grono przedsiębiorców nie potrzebuje prowadzenia własnego biura i chce zaoszczędzić koszty. Idea wirtualnego biura zyskała na wartości i już w 1995 roku pojawili się pierwsi klienci. Firma założona przez Ralpha Gregory funkcjonuje do dziś i cieszy się ogromnym zainteresowaniem klientów.
						</div>
					</div>
					<div class="faq-segment">
							<div class="question">
								<p>Jakie będę miał korzyści z Wirtualnego biura w stosunku do tradycyjnego biura?
								<span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span>
								</p>
							</div>
							<div class="answer">
								Przedsiębiorca, który postanowi korzystać z wirtualnego biura może liczyć na wiele korzyści, które wiążą się z tą opcją:
								<ul>
								<li>znaczny spadek kosztów utrzymania biura,</li>
						    <li>spadek kosztów związanych z wypłacaniem wynagrodzeń pracownikom,</li>
						    <li>uproszczenie w wypromowaniu firmy,</li>
						    <li>elastyczność w kwestii lokalizacji,</li>
						    <li>doświadczenie i bezpieczeństwo,</li>
						    <li>profesjonalny personel,</li>
						    <li>anonimowość prywatnych danych,</li>
						    <li>szereg dodatkowych usług administracyjnych.</li>
							</ul>
						</div>
					</div>
					<div class="faq-segment">
							<div class="question">
								<p>Czy pomożecie mi w założeniu firmy?
								<span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span>
								</p>
							</div>
							<div class="answer">
								Tak, na życzenie klienta zajmiemy się procesem rejestracji indywidualnej działalności gospodarczej lub sp. z o.o., jak również zajmiemy się prowadzeniem księgowości.
						</div>
					</div>
					<div class="faq-segment">
							<div class="question">
								<p>Czy adres pod jakim prowadzone jest Wirtualne biuro faktycznie istnieje?
								<span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span>
								</p>
							</div>
							<div class="answer">
								<p>Tak, pod adresem Opole, ul. 1-go Maja 30a znajduje się Biurowiec FAMILIA, który świadczy również najem lokali biurowych, handlowych oraz usługowych.Tak, na życzenie klienta zajmiemy się procesem rejestracji indywidualnej działalności gospodarczej lub sp. z o.o., jak również zajmiemy się prowadzeniem księgowości.
						</div>
					</div>
					<div class="faq-segment">
							<div class="question">
								<p>Pod jakie urzędy będę podlegał/a korzystając z Wirtualnego biura?
								<span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span>
								</p>
							</div>
							<div class="answer">
								W zależności od rodzaju prowadzonej działalności możesz korzystać ze wszystkich, bądź niektórych urzędów:
								<ul>
									<li>Pierwszy Urząd Skarbowy w Opolu</li>
							    <li>ZUS oddział w Opolu</li>
							    <li>Opolski Urząd Wojewódzki</li>
							    <li>Urząd Miasta Opola</li>
									<li>Powiatowy Urząd Pracy w Opolu</li>
								</ul>
							</div>
					</div>
					<div class="faq-segment">
							<div class="question">
								<p>Przykładowe odległości od naszego biura:
								<span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span>
								</p>
							</div>
							<div class="answer">
								W zależności od rodzaju prowadzonej działalności możesz korzystać ze wszystkich, bądź niektórych urzędów:
								<ul>
								<li>Pierwszy Urząd Skarbowy w Opolu - 0,9 km</li>
								<li>ZUS oddział w Opolu - 2,9 km</li>
								<li>Opolski Urząd Wojewódzki - 1,9 km</li>
								<li>Powiatowy Urząd Pracy w Opolu - 2,8 km</li>
								<li>Urząd Miasta Opola - 1,8 km</li>
								<li>Dworzec Główny PKS - 0,85 km</li>
								<li>Dworzec Główny PKP - 1,1 km</li>
								<li>Urząd Pocztowy - 1,1 km</li>
							</ul>
						</div>
					</div>
			</div>
		</div>
	</div>
	<div  id="contact"  class="row">
			<iframe src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBaIq44X1XHmqwZtFWOn62vsWqD_F9Xi5I&callback=initMap" "width="100%" height="600px" style="border:none;"></iframe>
	</div>
	<div  id="contact2"  class="row">
		<div class="container">
			<h2 class="text-center">Kontakt</h2>
			<div class="col-md-6 text-center">
				<h4><i class="icon-location"></i>Siedziba</h4>
				<p>
					Biurowiec Familia<br />
					ul. 1-go Maja 30a<br />
					45-355 Opole<br />
				</p>
				<h4><i class="icon-phone"></i>Zadzwoń</h4>
				<p>
					Marek Tarasiuk<br />
					<a href="tel:+48 693 582 295">tel. 693 582 295 </a>
				</p>
			</div>
			<div class="col-md-6 contact-form">
        <h4 class="text-center">Formularz kontaktowy</h4>
      <?php
        if(!isset($_SESSION['message_sent'])) require_once('contact-form.php');
        elseif( require_once('contact-confirmation.php'));
      ?>

			</div>
		</div>
	</div>
	<div  id="footer"  class="row">
		<div class="container">
			<p>&copy; <?php echo date("Y"); ?> wirtualnebiura.com.pl</p>
		</div>
	</div>
</main>
</div>
</body>
</html>
<?php
if(isset($_SESSION['message_not_sent']) || isset($_SESSION['message_sent']) || isset($_POST['confirm'])) {
  echo "<script>
        $.scrollTo($('#contact2'), 500);
        console.log('i am');
        </script>";
  //unset($_SESSION['go_to_contact_form']);
}
 ?>
