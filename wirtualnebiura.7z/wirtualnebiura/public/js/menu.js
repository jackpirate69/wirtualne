$( document ).ready(function() {
var clickMenu = false;
  $(".navbar .nav li").on('click', function(){
    clickMenu = true;
    if(clickMenu){
      $(".navbar .nav li").removeClass("active");
      $(this).addClass("active");
    }
    var link = $(this).find("a").attr("data-link");
    link = "#" + link;
    console.log(link);
    $.scrollTo($(link), 350, {
        offset: {top: -50},
        onAfter: function() {
          requestAnimationFrame(function() {
              clickMenu = false
          });
        }
      });

  })

$(".navbar .nav li").each(function(index){
  var link = $(this).find("a").data('link');
  $("#" + link).waypoint(function(direction) {
    if(!clickMenu){
      $(".navbar .nav li").removeClass("active");
      $('.navbar .nav li a[data-link="' + link +'"]').parent().addClass("active");
    }
    var position = $("#" + link).offset().top;
  },{ offset: 49 });
  });

  $(window).scroll(function(){
      if($(this).scrollTop()>300) $(".navbar-default").addClass("navbar-smaller");
      else $(".navbar-default").removeClass("navbar-smaller");
  });
});
