$( document ).ready(function() {
  $(".question").on('click', function(){
    if($(this).hasClass("active")){
      $(".faq-segment .answer").hide("slow");
      $(".faq-segment .question").removeClass("active");
      $(this).find("span").css("transform", "rotate(0deg)")
    } else {
      $(".faq-segment .answer").hide("slow");
      $(".faq-segment .question").removeClass("active");
      $(".faq-segment .question span").css("transform", "rotate(0deg)")
      $(this).addClass("active");
      $(this).next().show("slow");
      $(this).find("span").css("transform", "rotate(180deg)")
    }
  })
});
