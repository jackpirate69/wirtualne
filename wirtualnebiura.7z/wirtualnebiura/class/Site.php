<?php
class Site {
  public function sendEmail() {

 		 $everythingIsCorrect = true;

 		 $name = $_POST['name'];
 		 if(!isset($_POST['name'])){
 				 $everythingIsCorrect = false;
 				 $_SESSION['e_name'] = "To pole jest obowiązkowe";
 		 }

 		 $email = $_POST['email'];
 		 $emailB = filter_var($email, FILTER_SANITIZE_EMAIL);
 		 if((filter_var($emailB, FILTER_VALIDATE_EMAIL)) == false || ($emailB != $email)){
 				 $everythingIsCorrect = false;
 				 $_SESSION['e_email'] = "Podaj poprawny adres email.";
 		 }

 		 $phone = $_POST['phone'];

 		 $sekret = "6LcBcoUUAAAAACaUeAzLxqsOOK5HBE_AEGIpnU6M";
 		 $sprawdz = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".$sekret."&response=".$_POST['g-recaptcha-response']);

 		 $odpowiedz = json_decode($sprawdz);

 		 if($odpowiedz->success == false){
 				 $everythingIsCorrect = false;
 				 $_SESSION['e_bot'] = "Potwierdź że nie jestes botem.";
 		 }

 		 $message = $_POST['message'];
 		 if((strlen($message)<10)){
 				 $everythingIsCorrect = false;
 				 $_SESSION['e_message'] = "Ta wiadomość jest zbyt krótka";
 		 }

      if(!isset($_POST['regimen'])){
          $everythingIsCorrect = false;
          $_SESSION['e_regimen'] = "Potwierdź akceptację regulaminu.";
      }

 		 if($everythingIsCorrect){
 			 $messageToSend1 = $name. " wysłał wiadomość za pomocą formularza na stronie o treści:<br><br>";
 			 $messageToSend1.= $message;
 			 if($phone)  $messageToSend1.= "<br><br>".$name." podał nr telefonu: ".$phone;
 			 else  $messageToSend1.="<br><br>".$name." nie podał nr telefonu.";
       $email = new EmailSent('marek.tarasiuk@icloud.com', 'Marek Tarasiuk', $email ,$name, $messageToSend1);
       $email->send();
       $_SESSION['message_sent'] = true;

 		 } else {
 			 $_SESSION['fr_name'] = $name;
 			 $_SESSION['fr_email'] = $email;
 			 $_SESSION['fr_phone'] = $phone;
 			 $_SESSION['fr_message'] = $message;
       $_SESSION['message_not_sent'] = true;
 		 }
  }
  public function setMessage($message){

  }

}
