<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class EmailSent {
  private $mail = null;
  public function __construct($recipient_email, $recipient_name, $sender_email ,$sender_name, $message){
    $this->config($recipient_email, $recipient_name, $sender_email ,$sender_name,$message);
  }

  private function config($recipient_email, $recipient_name,$sender_email ,$sender_name, $message){
    $this->mail = new PHPMailer(true);
    $this->mail->CharSet = 'UTF-8';
    $this->mail->isSMTP();                                      // Set mailer to use SMTP
    $this->mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
    $this->mail->SMTPAuth = true;                               // Enable SMTP authentication
    $this->mail->Username = 'noreplywirtualnebiura@gmail.com';                 // SMTP username
    $this->mail->Password = 'ZAQ!2wsx';                           // SMTP password
    $this->mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
    $this->mail->Port = 587;                                    // TCP port to connect to

    //Recipients
    $this->mail->setFrom('noreplywirtualnebiura@gmail.com', 'Wirtualnebiura.com');
    $this->mail->addAddress($recipient_email, $recipient_name);     // Add a recipient
    $this->mail->addBcc('p.nieslony@gmail.com', 'webmaster');
    $this->mail->addReplyTo($sender_email, $sender_name);

    //Content
    $this->mail->isHTML(true);                                  // Set email format to HTML
    $this->mail->Subject = 'Wiadomość ze strony WirtualneBiura.com.pl';
    $this->mail->Body  = $message;
  }
  public function send(){
    $this->mail->send();
  }
}
